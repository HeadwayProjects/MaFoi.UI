import React from "react";

export default function Stepper({ children }: any) {
    return (
        <div>{children}</div>
    )
}